#ifndef __USERPROGRAM_H_
#define __USERPROGRAM_H_

void initProgram();
void loopProgram();
#endif
