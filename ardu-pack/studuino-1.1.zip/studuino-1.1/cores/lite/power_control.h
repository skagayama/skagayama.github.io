#ifndef __POWERCONTROL_H__
#define __POWERCONTROL_H__

const byte M1 = 0;
const byte M2 = 1;

const byte M1_PWM1_PIN = 5;
const byte M1_PWM2_PIN = 6;
const byte M2_PWM1_PIN = 9;
const byte M2_PWM2_PIN = 10;

const byte STOP    = 1;
const byte FORWARD = 2;
const byte REVERSE = 3;
const byte BRAKE   = 4;

void DCmotorControl_100msOFF();
void DCmotorControl_ChangeCheck();
void DCmotorControl_MoveCheck();
void DCmotorControl_AllOFF();
void DCmotorControl(unsigned char ID, unsigned char func, unsigned char val);

#endif