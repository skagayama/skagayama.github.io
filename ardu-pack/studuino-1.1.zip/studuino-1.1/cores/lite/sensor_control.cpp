#include <Arduino.h>
#include "sensor_control.h"
#include "waiting.h"

uint16_t Val_LightSensor, Val_IR, Val_A1, Val_A2;
float Val_temp;

long light_val = 0;
long IR_val = 0;

bool getButtonState(void) {
  return digitalRead(ONBOARD_BUTTON_PIN);
}

long getLightSensor(void) {
  light_val = (long)analogRead(ONBOARD_LIGHT_SENSOR_PIN)*100/1023;
  return light_val;
}

void IR_LED_ON(){
  digitalWrite(ONBOARD_IR_LED_PIN, 1);
  waiting(2);  //  wait for LED current to be stable.
}

void IR_LED_OFF(){
  digitalWrite(ONBOARD_IR_LED_PIN, 0);
}

long getIRPhotoreflector(void) {
  IR_LED_ON();
  IR_val = (long)analogRead(ONBOARD_IR_PHOTOREFLECTOR_PIN)*100/1023;
  IR_LED_OFF();
  return IR_val;
}

float getTemperature_celsius(void) {
  float val = analogRead(ONBOARD_TEMPERATURE_SENSOR_PIN);
  val = 1023.0 / val - 1.0;
  val = SERIESRESISTOR * val;  //  Series resistor is tied to GND. (So, Not "SERIESRESISTOR / val") 
  
  float steinhart = val / THERMISTORNOMINAL;           // (R/Ro)
  steinhart = log(steinhart);                          // ln(R/Ro)
  steinhart /= BCOEFFICIENT;                           // 1/B*ln(R/Ro)
  steinhart += 1.0 / (TEMPERATURENOMINAL + 273.15);    // + (1/To)
  steinhart = 1.0 / steinhart;                         // Invert
  steinhart -= 273.15;                                 // convert to C
  steinhart = int(steinhart * pow(10, 1)) / pow(10, 1);
  return steinhart;
}