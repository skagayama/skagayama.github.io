#include <Arduino.h>
#include "power_control.h"
#include "waiting.h"

unsigned char DC_Motor_PWM_Pin[2][2] = {{M1_PWM1_PIN, M1_PWM2_PIN},
                                        {M2_PWM1_PIN, M2_PWM2_PIN}};

unsigned char PORT        = 0;
unsigned char direction   = 0;
unsigned char vallue      = 0;
unsigned char M1_val      = 0;
unsigned char M1_pre_val  = 0;
unsigned char M1_func     = 0;
unsigned char M1_pre_func = 0;
unsigned char M2_val      = 0;
unsigned char M2_pre_val  = 0;
unsigned char M2_func     = 0;
unsigned char M2_pre_func = 0;

unsigned char flag_val_change  = 0;
unsigned char flag_func_change = 0;

void DCmotorControl_100msOFF(){
  if(flag_func_change==1 || flag_val_change==1){
    analogWrite(DC_Motor_PWM_Pin[M1][0], 255);
    analogWrite(DC_Motor_PWM_Pin[M1][1], 255);
    analogWrite(DC_Motor_PWM_Pin[M2][0], 255);
    analogWrite(DC_Motor_PWM_Pin[M2][1], 255);
    waiting(100);
  }
}

void DCmotorControl_ChangeCheck(){ //M1とM2のfuncとvalが変更されていないかをチェック
  if(PORT == M1){
    M1_val  = vallue;     //M1への出力%を保存
    M1_func = direction;  //M1への電流の向きを保存

    if(M1_val == M1_pre_val){
      flag_val_change = 0;
    }
    else{
      M1_pre_val = M1_val;
      flag_val_change = 1;
    }

    if(M1_func == M1_pre_func){
      flag_func_change = 0;
    }
    else{
      M1_pre_func = M1_func;
      flag_func_change = 1;
    }
  }
  else if(PORT == M2){
    M2_val  = vallue;     //M2への出力%を保存
    M2_func = direction;  //M2への電流の向きを保存

    if(M2_val == M2_pre_val){
      flag_val_change = 0;
    }
    else{
      M2_pre_val = M2_val;
      flag_val_change = 1;
    }

    if(M2_func == M2_pre_func){
      flag_func_change = 0;
    }
    else{
      M2_pre_func = M2_func;
      flag_func_change = 1;
    }
  }
}

void DCmotorControl_MoveCheck(){
  if(PORT == M1){
    if(M2_func == FORWARD){
      analogWrite(DC_Motor_PWM_Pin[M2][0], 255);
      analogWrite(DC_Motor_PWM_Pin[M2][1], 255-M2_val);
    }
    else if(M2_func == REVERSE){
      analogWrite(DC_Motor_PWM_Pin[M2][0], 255-M2_val);
      analogWrite(DC_Motor_PWM_Pin[M2][1], 255);
    }
  }
  else if(PORT == M2){
    if(M1_func == FORWARD){
      analogWrite(DC_Motor_PWM_Pin[M1][0], 255);
      analogWrite(DC_Motor_PWM_Pin[M1][1], 255-M1_val);
    }
    else if(M1_func == REVERSE){
      analogWrite(DC_Motor_PWM_Pin[M1][0], 255-M1_val);
      analogWrite(DC_Motor_PWM_Pin[M1][1], 255);
    }
  }
}

void DCmotorControl_AllOFF(){
  M1_val = 0;
  M2_val = 0;
  M1_func = 1;
  M2_func = 1;
}

void DCmotorControl(unsigned char ID, unsigned char func, unsigned char val){
  //  val: slow <- 0-255 -> fast
  if(ID == M1 || ID == M2){
    PORT      = ID;
    direction = func;
    vallue    = val;
    switch(func){
      case STOP:      //1
        analogWrite(DC_Motor_PWM_Pin[ID][0], 0);
        analogWrite(DC_Motor_PWM_Pin[ID][1], 0);
        break;
      case FORWARD:   //2
        DCmotorControl_ChangeCheck();
        DCmotorControl_100msOFF();
        analogWrite(DC_Motor_PWM_Pin[ID][0], 255);
        analogWrite(DC_Motor_PWM_Pin[ID][1], 255-val);
        DCmotorControl_MoveCheck();
        break;
      case REVERSE:   //3
        DCmotorControl_ChangeCheck();
        DCmotorControl_100msOFF();
        analogWrite(DC_Motor_PWM_Pin[ID][0], 255-val);
        analogWrite(DC_Motor_PWM_Pin[ID][1], 255);
        DCmotorControl_MoveCheck();
        break;
      case BRAKE:     //4
        DCmotorControl_AllOFF();
        analogWrite(DC_Motor_PWM_Pin[ID][0], 255);
        analogWrite(DC_Motor_PWM_Pin[ID][1], 255);
        break;
    }
  }
}