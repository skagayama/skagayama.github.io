#ifndef __SENSORCONTROL_H__
#define __SENSORCONTROL_H__

const byte ONBOARD_BUTTON_PIN             = 14; //A0,23pin
const byte ONBOARD_LIGHT_SENSOR_PIN       = A6; //A6,19pin
const byte ONBOARD_IR_PHOTOREFLECTOR_PIN  = A7; //A7,22pin
const byte ONBOARD_TEMPERATURE_SENSOR_PIN = 17; //A3,26pin
const byte ONBOARD_IR_LED_PIN             = 3;
const byte ONBOARD_LED_PIN                = 13;

#define THERMISTORNOMINAL       10000
  // resistance at 25 degrees C
#define TEMPERATURENOMINAL      25
  // temp. for nominal resistance (almost always 25 C)
#define NUMSAMPLES              5
  // how many samples to take and average, more takes longer
  // but is more 'smooth'
#define BCOEFFICIENT            3950
  // The beta coefficient of the thermistor (usually 3000-4000)
#define SERIESRESISTOR          10000
  // the value of the 'other' resistor

bool getButtonState(void);
long getLightSensor(void);
void IR_LED_ON();
void IR_LED_OFF();
long getIRPhotoreflector(void);
float getTemperature_celsius(void);
void checkUSB();

#endif