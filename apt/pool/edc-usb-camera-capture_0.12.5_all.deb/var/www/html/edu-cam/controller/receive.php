<?php

/**
 * DataURI Schemaを受け取り保存する
 *
 */

//-------------------------------------------------
// 定数
//-------------------------------------------------
// 画像を保存するディレクトリ
define('SAVE_DIR', '../images/');

/**
 * base64形式の画像データを保存
 *
 */
function saveImage($base64, $path)
{
    // Base64をバイナリに戻す
    // $name = $json['name'];
    // $data = $json['data'];
    // $data = str_replace('data:image/png;base64,', '', $base64);  // 冒頭の部分を削除
    $data = str_replace('data:image/jpeg;base64,', '', $base64);  // 冒頭の部分を削除
    $data = str_replace(' ', '+', $data);  // 空白を'+'に変換
    $image = base64_decode($data);

    // ファイルへ保存
    // $file = sprintf('%s.png', uniqid());    //ファイル名を作成
    // $file = "$name.png";
    $result = file_put_contents(SAVE_DIR . $path, $image, LOCK_EX);
    return $result;
}

//-------------------------------------------------
// POSTで渡されたJSONを取得
//-------------------------------------------------
$json = getParamJSON();

//-------------------------------------------------
// Validation
//-------------------------------------------------
// Snapshotリクエスト
if (isset($json['command'])) {
    switch ($json['command']) {
        case 'change-config':
            $arr = array(
                "size" => intval($json['value']['size']),
                "qual" => intval($json['value']['qual']),
                "rate" => intval($json['value']['rate'])
            );
            file_put_contents(SAVE_DIR . "config.json", json_encode($arr));
            sendResult(true, "config changed.");
            exit(0);
        case 'snapshot':
            $dest = $json['index'];
            $path = 'ss0' . $dest . '.jpg';
            $cmd = SAVE_DIR . "conv.sh $dest"; //OK
            if (isset($json['pen'])) {
                $cmd = $cmd . " pen"; //OK
            }
            $result = shell_exec($cmd);
            // スナップショット更新日時
            $arr = array(
                "lastUpdate" => $dest,
                "time" => date("YmdHis")
            );
            file_put_contents(SAVE_DIR . "info.json", json_encode($arr));
            sendResult(true, "Snapshot uploaded.");
            exit(0);
        case 'get-pass':
            $cmd = "grep wpa_passphrase /etc/hostapd/edu-cam | cut -d= -f2"; //OK
            $result = shell_exec($cmd);
            sendResult(true, $result);
            exit(0);
    }

    if ($result) sendResult(false, $result);
    else sendResult(true, 'Snapshot succeeded.');  // ブラウザにファイル名を返却する

    exit;
}
// dataが渡されているか
if (!isset($json['data'])) {
    sendResult(false, 'Empty query parameter: data');
    exit(1);
}
// データ長が30kbyte以下か
if (strlen($json['data']) > (1024 * 1024)) {
    sendResult(false, 'Too long string: data');
    exit(1);
}
// 中身がDataURISchemaか
if (!preg_match('/^data:image\/png;base64,/', $json['data'])) {
    sendResult(false, 'Not Allow data type: data');
    exit(1);
}

//-------------------------------------------------
// サーバへ保存
//-------------------------------------------------
// Base64をバイナリに戻す
$name = $json['name'];
$data = $json['data'];
$data = str_replace('data:image/png;base64,', '', $data);  // 冒頭の部分を削除
$data = str_replace(' ', '+', $data);  // 空白を'+'に変換
$image = base64_decode($data);

// ファイルへ保存
// $file = sprintf('%s.png', uniqid());    //ファイル名を作成
$file = "$name.png";
$result = file_put_contents(SAVE_DIR . $file, $image, LOCK_EX);

//-------------------------------------------------
// 結果を返却
//-------------------------------------------------
if ($result !== false) {
    sendResult(true, $file);  // ブラウザにファイル名を返却する
} else {
    // 書き込みエラー
    sendResult(false, 'Can not write image data');
}


/**
 * POSTで渡されたJSONを取得する
 *
 * @return object
 */
function getParamJSON()
{
    $buff = file_get_contents('php://input');
    $json = json_decode($buff, true);

    return ($json);
}

/**
 * 結果をJSON形式で返却
 *
 * @param  boolean $status 成功:true, 失敗:false
 * @param  mixed   $data   ブラウザに返却するデータ
 * @return void
 */
function sendResult($status, $data)
{
    // CORS (必要に応じて指定)
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Headers: *');

    echo json_encode([
        "status" => $status,
        "result" => $data
    ]);
}
