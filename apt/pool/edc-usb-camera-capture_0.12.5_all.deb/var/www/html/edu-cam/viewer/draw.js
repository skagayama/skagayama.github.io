function reloadImage() {
    console.log('reload');
    const url = `../images/input.png?${new Date().getTime()}`;
    const img = document.getElementById("ss_img");
    img.setAttribute('src', url);
}

function loadSS() {
    getJson();
}

function getJson() {
    fetch(`../images/info.json?${new Date().getTime()}`)
        .then(response => {
            return response.json();
        })
        .then(json => {
            const index = json.lastUpdate;
            const url = `../images/ss0${index}.jpg?${json.time}`;
            const img = document.getElementById(`0${index}`).childNodes[1];
            const disp = document.getElementById(`0${index}`).childNodes[3];
            img.setAttribute('src', url);
            disp.textContent = json.time.slice(8, 14).match(/.{2}/g).join(':');
        });
}