#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os
import multiprocessing as mp
import subprocess
from ctypes import c_char_p
import json
import time
import cv2

SIZE = [(320, 240), (520, 390), (640, 480), (800, 600), (1920, 1080)]
PATH_SS = '/var/www/html/edu-cam/images/ss'
PATH_CONFIG = '/var/www/html/edu-cam/images'

config = ''
last_ss = time.time()

cap = cv2.VideoCapture(0)

def loadConf():
    global config
    with open(PATH_CONFIG + '/config.json', 'r') as f:
        config = json.load(f)

def snapshot(path):
    """
    スナップショットをライブ映像のキャプチャと別で行うと時間が掛かるので、
    基本的には使用せず、ライブ用のキャプチャ画像をそのままコピーする。(PHPで処理)
    """
    ret, frame = cap.read()  # 1フレーム読み込む
    resized = cv2.resize(frame, SIZE[config['size']])

    # usbカメラの画像をpathに出力
    cv2.imwrite(path, resized, [
                cv2.IMWRITE_JPEG_QUALITY, config['qual'] * 10])

loadConf()

try:
    while(True):
        if time.time() - last_ss < (0.5 / config['rate']):
            continue
        last_ss = time.time()
        loadConf()

        snapshot(PATH_SS + '/pic.jpg')

except KeyboardInterrupt:
    cap.release()
    cv2.destroyAllWindows()
