#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os
import multiprocessing as mp
import subprocess
from ctypes import c_char_p
import json
import time
import cv2

SIZE = [(320, 240), (520, 390), (640, 480), (800, 600), (1920, 1080)]
PATH_SS = '/var/www/html/edu-cam/images/ss'
PATH_CONFIG = '/var/www/html/edu-cam/images'


class CaptureControl(mp.Process):
    def __init__(self):
        super(CaptureControl, self).__init__()
        # VideoCaptureのインスタンスを作成する。(複数のカメラがあるときは引数で識別)
        self.cap = cv2.VideoCapture(0)
        self.lock = mp.Lock()
        self.exit = mp.Event()
        self.last_ss = time.time()
        self.loadConf()

    def loadConf(self):
        with open(PATH_CONFIG + '/config.json', 'r') as f:
            self.config = json.load(f)

    def run(self):
        try:
            while(True):
                if time.time() - self.last_ss < (0.5 / self.config['rate']):
                    continue
                self.last_ss = time.time()
                self.loadConf()

                self.snapshot(PATH_SS + '/pic.jpg')

                if self.exit.is_set():
                    self.cap.release()
                    cv2.destroyAllWindows()
                    break
        except KeyboardInterrupt:
            self.cap.release()
            cv2.destroyAllWindows()

    def snapshot(self, path):
        """
        スナップショットをライブ映像のキャプチャと別で行うと時間が掛かるので、
        基本的には使用せず、ライブ用のキャプチャ画像をそのままコピーする。(PHPで処理)
        """
        self.lock.acquire()
        ret, frame = self.cap.read()  # 1フレーム読み込む
        resized = cv2.resize(frame, SIZE[self.config['size']])

        # usbカメラの画像をpathに出力
        cv2.imwrite(path, resized, [
                    cv2.IMWRITE_JPEG_QUALITY, self.config['qual'] * 10])
        self.lock.release()

    def shutdown(self):
        self.exit.set()


if __name__ == "__main__":
    p = CaptureControl()
    p.start()
    try:
        p.join()
    except KeyboardInterrupt:
        pass
