#!/bin/bash
PATH_EDU=/etc/edu-cam/apmode/settings
cd $PATH_EDU

sudo cp ap_mode/etc/dhcpcd.conf /etc/
sudo cp ap_mode/etc/dnsmasq.conf /etc/
sudo ln -s $PATH_EDU/ap_mode/etc/network/interfaces /etc/network/interfaces.d/edu-cam

sudo update-rc.d -f apache2 defaults
sudo update-rc.d -f hostapd defaults
sudo update-rc.d -f dnsmasq defaults
sudo update-rc.d -f edu-cam defaults
sudo update-rc.d -f edu-cam-streaming defaults

if [ "$1" == "multi" ]; then
  sudo touch /var/edu-cam/multi
  sudo cp config.js /var/www/html/edu-cam/controller/
fi
sudo cp /etc/edu-cam/autostart/chromium.desktop /home/educom/.config/autostart/

sudo reboot
