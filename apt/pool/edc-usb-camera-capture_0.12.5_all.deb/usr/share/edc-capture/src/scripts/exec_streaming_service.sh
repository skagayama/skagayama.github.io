#!/bin/bash
if [ "$1" == "just-open" ]; then
  exec chromium-browser http://localhost/edu-cam/controller/
  exit 0
fi

if [ "$2" == "multi" ]; then
  sudo touch /var/edu-cam/multi
  sudo cp /etc/edu-cam/apmode/settings/config.js /var/www/html/edu-cam/controller/
fi
sudo service edu-cam-streaming $1


if [ "$1" == "start" ]; then
  exec chromium-browser http://localhost/edu-cam/controller/
fi
