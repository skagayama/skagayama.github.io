#
# Copyright (c) 2020 Artec Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the License);
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at:
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an AS IS BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# reference data
# https://qiita.com/kotai2003/items/3d31528d56059c848458

# For Translation
import bootstrap
bootstrap.init_translation()

import tkinter as tk
from tkinter import ttk
from tkinter import filedialog
from tkinter import font
from tkinter import messagebox
import cv2
import PIL.Image, PIL.ImageTk, PIL.ImageEnhance
#import time
import datetime
import sys
import subprocess

import pygame.mixer

class Application(tk.Frame):
    def __init__(self, master, config, video_source=0):
        super().__init__(master)

        self.file = config[0]
        path = '/home/' + config[1] + '/Pictures'
        with open(self.file) as f:
            s = f.read()
            if (s != ''): path = s

        self.path = tk.StringVar()
        self.path.set(path)

        self.master.geometry('1024x700')
        self.master.title(_('Camera Feed'))


        # ---------------------------------------------------------
        # Font
        # ---------------------------------------------------------

        self.font_frame = font.Font(family="Meiryo UI", size=15, weight="normal")

        # ---------------------------------------------------------
        # Open the video source
        # ---------------------------------------------------------

        self.vcap = cv2.VideoCapture( video_source )
        self.width = int(self.vcap.get( cv2.CAP_PROP_FRAME_WIDTH ))
        self.height = int(self.vcap.get( cv2.CAP_PROP_FRAME_HEIGHT ))

        # ---------------------------------------------------------
        # Widget
        # ---------------------------------------------------------

        self.create_widgets()

        # ---------------------------------------------------------
        # Canvas Update
        # ---------------------------------------------------------

        self.delay = 15 #[mili seconds]
        self.update()


    def create_widgets(self):

        #Frame_Camera
        self.frame_cam = tk.Frame(self.master)
        self.frame_cam.place(x=10, y=10)
        self.frame_cam.configure(width=self.width+30, height=self.height+30)
        self.frame_cam.grid_propagate(0)
        self.frame_cam.grid(column=0, row=0, padx=10, pady=10, sticky=tk.N)

        #Canvas
        self.canvas1 = tk.Canvas(self.frame_cam)
        self.canvas1.configure(width=self.width, height=self.height,)
        self.canvas1.grid_propagate(0)
        self.canvas1.grid(column=0, row=0, padx=10, pady=10)

        # Frame_Control
        self.frame_ctrl = tk.Frame( self.master)
        self.frame_ctrl.place( x=10, y=10 )
        self.frame_ctrl.configure( width=320, height=680 )
        self.frame_ctrl.grid_propagate( 0 )
        self.frame_ctrl.grid(column=1, row=0, padx=0, pady=0, sticky=tk.N)

        # Frame_Button
        self.frame_btn = tk.LabelFrame( self.frame_ctrl, text=_('Controls'), font=self.font_frame )
        self.frame_btn.place( x=10, y=10 )
        self.frame_btn.configure( width=320, height=170 )
        self.frame_btn.grid_propagate( 0 )
        self.frame_btn.grid(column=0, row=0, padx=0, pady=0, sticky=tk.N)

        #Snapshot Button
        self.btn_snapshot = tk.Button(self.frame_btn, text=_('Snapshot'))
        self.btn_snapshot.configure(width=15, height=5, command=self.press_snapshot_button)
        self.btn_snapshot.grid(column=0, row=0, padx=5, pady=5)

        #Open Button
        self.btn_open = tk.Button(self.frame_btn, text=_('Open Folder'))
        self.btn_open.configure(width=15, height=5, command=self.press_open_button)
        self.btn_open.grid(column=1, row=0, padx=5, pady=5)

        # Frame_Button
        self.frame_path = tk.LabelFrame( self.frame_ctrl, text=_('Save Folder'), font=self.font_frame )
        self.frame_path.place( x=10, y=10 )
        self.frame_path.configure( width=320, height=120 )
        self.frame_path.grid_propagate( 0 )
        self.frame_path.grid(column=0, row=1, padx=0, pady=0, sticky=tk.N)

        # Path
        self.lbl_path = ttk.Label(self.frame_path, textvariable=self.path)
        self.lbl_path.grid(column=0, row=0, padx=10, pady=5)

        ## Path Button
        self.btn_path = tk.Button(self.frame_path, text=_('Browse'))
        self.btn_path.configure(width=8, height=1, command=self.press_select_button)
        self.btn_path.grid(column=0, row=1, padx=10, pady=5, sticky=tk.W)

    def update(self):
        #Get a frame from the video source
        _, frame = self.vcap.read()

        frame = cv2.resize(frame, dsize=(self.width, self.height))
        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        self.photo = PIL.ImageTk.PhotoImage(image=PIL.Image.fromarray(frame))

        #self.photo -> Canvas
        self.canvas1.create_image(0, 0, image=self.photo, anchor=tk.NW)

        self.master.after(self.delay, self.update)

    def press_snapshot_button(self):
        pygame.mixer.music.load('decision4.mp3')
        pygame.mixer.music.play(1)
        # Get a frame from the video source
        _, frame = self.vcap.read()

        frame1 = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

        now = datetime.datetime.now()
        cv2.imwrite(self.path.get() + '/' + now.strftime('%Y%m%d_%H%M%S') + '.jpg',
                     cv2.cvtColor( frame1, cv2.COLOR_BGR2RGB ) )


    def press_select_button(self):
        fld = filedialog.askdirectory(initialdir=self.path.get())
        if fld != '':
            if fld.split('/')[1] != 'home':
                messagebox.showerror(_('Error'), _('Select a folder in /home'))
                self.press_select_button()
            else:
                self.path.set(fld)
                with open(self.file, mode='w') as f:
                    f.write(fld)

    def press_open_button(self):
        subprocess.run(('pcmanfm', self.path.get())) 


def main():
    pygame.mixer.init(frequency=44100)

    root = tk.Tk()
    app = Application(master=root, config=(sys.argv[1], sys.argv[2]))
    app.mainloop()

if __name__ == "__main__":
    main()
    