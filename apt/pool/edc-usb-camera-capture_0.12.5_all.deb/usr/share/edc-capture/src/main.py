#!/usr/bin/env python3.7
# -*- coding: utf-8 -*-
import os
import sys
import signal
import subprocess
import re
from tkinter import Tk
from tkinter import ttk
from tkinter import *
import time


def exec_command(command, wait=False):
    subproc = subprocess.Popen(
        command, stdout=subprocess.PIPE, shell=True, preexec_fn=os.setsid)
    if wait:
        subproc.wait()
        return subproc.communicate()


def check_service():
    command = 'test -e /var/lock/subsys/edu-cam; echo $?'
    outs, errs = exec_command(command, True)
    service_ap = outs.decode()[0]

    command = 'test -e /var/lock/subsys/edu-cam-streaming; echo $?'
    outs, errs = exec_command(command, True)
    service_streaming = outs.decode()[0]

    command = 'test -e /var/edu-cam/multi; echo $?'
    outs, errs = exec_command(command, True)
    proc_multi = outs.decode()[0]

    command = "ps -e -o pid,cmd | grep [m]jpg-streamer | cut -d' ' -f2"
    outs, errs = exec_command(command, True)
    proc_streaming = outs.decode()

    return (service_ap == '0', service_streaming == '0', proc_multi == '0', proc_streaming != '')


root = Tk()
root.title(u"USBカメラキャプチャー")
root.geometry("630x500+200+30")
root.resizable(False, False)

img_cap = PhotoImage(file=os.path.dirname(__file__) + '/images/cap.png')
img_cap = img_cap.subsample(6, 6)
img_streaming_s = PhotoImage(
    file=os.path.dirname(__file__) + '/images/stream_s.png')
img_streaming_s = img_streaming_s.subsample(6, 6)
img_streaming_m = PhotoImage(
    file=os.path.dirname(__file__) + '/images/stream_m.png')
img_streaming_m = img_streaming_m.subsample(6, 6)


class AppFrame(ttk.Frame):
    def __init__(self, root):
        super().__init__(root, padding=10)
        self.root = root
        self.grid()

        # Capture
        ttk.Button(self, image=img_cap, command=lambda: self.start_cap()).grid(
            row=0, column=0, columnspan=2)
        ttk.Label(self, padding=10, text=u'＜画像撮影モード＞\nUSBカメラの画像を撮影してエデュコンに保存します。', font=(
            "Meiryo", "11"), wraplength="400").grid(row=0, column=3, columnspan=2)

        # Streaming (single)
        ttk.Button(self, image=img_streaming_s,
                   command=lambda: self.start_streaming()).grid(row=1, column=0, columnspan=2)
        ttk.Label(self, padding=10, text=u'＜発表モード＞\n※Wi-Fiアダプタが必要です。\n高画質のため電子黒板などへの1対1での配信に適しています。', font=(
            "Meiryo", "11"), wraplength="400").grid(row=1, column=3, columnspan=2)

        # Streaming (multi)
        ttk.Button(self, image=img_streaming_m,
                   command=lambda: self.start_streaming(True)).grid(row=2, column=0, columnspan=2)
        ttk.Label(self, padding=10, text=u'＜同時配信モード＞\n※Wi-Fiアダプタが必要です。\n複数の端末への同時画像配信に適しています。画質やフレームレートを調整できます。\n同時配信台数が増えるほど処理が重たくなるため、画質やフレームレートを調整してください。\n（推奨最大接続台数8台）', font=(
            "Meiryo", "11"), wraplength="400").grid(row=2, column=3, columnspan=2)

        # Setting
        ttk.Button(self, text='AP設定変更', command=self.openSetting).grid(
            row=3, column=4)

    def validator(self, P):
        pattern = '\A[\w, \.]{8,20}\Z'
        repatter = re.compile(pattern)
        result = repatter.match(P)
        if result:
            self.error_text.set('入力OK')
            self.btn_ok['state'] = 'normal'
            self.lbl_err['foreground'] = '#0000ff'
        else:
            self.error_text.set('8-20文字の半角英数のみご使用ください。')
            self.btn_ok['state'] = 'disable'
            self.lbl_err['foreground'] = '#ff0000'
        return True

    def openSetting(self):

        self.dialog = Toplevel(self)
        self.dialog.title("AP設定変更")
        self.dialog.grab_set()
        self.dialog.resizable(False, False)
        self.dialog.attributes("-topmost", True)

        frame = ttk.Frame(self.dialog, padding=20)
        frame.pack()
        lbl = ttk.Label(frame, text=u'新しいパスワードを入力してください', font=(
            "Meiryo", "12"))
        lbl.pack(pady=5)

        ttk.Label(frame, text="現在のパスワード: {}".format(
            self.get_ap_pass()), font=("Meiryo", "10")).pack(pady=5)

        val_cmd = self.root.register(self.validator)
        password = StringVar()
        textInput = ttk.Entry(frame, textvariable=password, width=20, validatecommand=(
            val_cmd, '%P'), validate='key')
        textInput.pack(pady=5)

        self.error_text = StringVar(frame)
        self.error_text.set('新しいパスワードを入力してください')
        self.lbl_err = ttk.Label(
            frame, textvariable=self.error_text, font=("Meiryo", "10"))
        self.lbl_err.pack(pady=5)

        self.btn_ok = ttk.Button(
            frame, text='OK', command=lambda: self.change_ap_pass(password.get()))
        self.btn_ok['state'] = 'disable'
        self.btn_ok.pack(pady=5)

        btn_back = ttk.Button(frame, text='戻る', command=self.closeDialog)
        btn_back.pack(pady=5)

        ww = self.root.winfo_screenwidth()
        wh = self.root.winfo_screenheight()
        self.dialog.update_idletasks()
        lw = self.dialog.winfo_width()
        lh = self.dialog.winfo_height()
        self.dialog.geometry("+"+str(int(ww/2-lw/2))+"+"+str(int(wh/2-lh/2)))

    def openDialog(self, multi=False):
        self.dialog = Toplevel(self)
        self.dialog.title("再起動の確認")
        self.dialog.grab_set()
        self.dialog.resizable(False, False)
        self.dialog.attributes("-topmost", True)

        frame = ttk.Frame(self.dialog, padding=20)
        frame.pack()
        lbl = ttk.Label(frame, text=u'エデュコンを再起動します。よろしいですか？', font=(
            "Meiryo", "12"))
        lbl.pack(pady=5)
        btn_ok = ttk.Button(
            frame, text='OK', command=lambda: self.start_ap(multi))
        btn_ok.pack(pady=5)
        btn_back = ttk.Button(frame, text='戻る', command=self.closeDialog)
        btn_back.pack(pady=5)

        ww = self.root.winfo_screenwidth()
        wh = self.root.winfo_screenheight()
        self.dialog.update_idletasks()
        lw = self.dialog.winfo_width()
        lh = self.dialog.winfo_height()
        self.dialog.geometry("+"+str(int(ww/2-lw/2))+"+"+str(int(wh/2-lh/2)))

    def closeDialog(self):
        self.dialog.destroy()

    def start_cap(self):
        ap_active, streaming_active, _, __ = check_service()
        if ap_active and streaming_active:
            self.exec_streaming_service('stop')

        command = os.path.dirname(__file__) + '/scripts/start_capture.sh'
        exec_command(command)
        self.root.quit()

    def start_streaming(self, multi=False):
        ap_active, streaming_active, is_multi, proc_alive = check_service()
        if not ap_active:
            self.openDialog(multi)
            return

        if streaming_active:
            if proc_alive:
                if multi == is_multi:
                    # Just opening the controller page on Chromium.
                    self.exec_streaming_service('just-open')
                    self.root.quit()
                    return
                else:
                    # Stopping the current streaming mode.
                    self.exec_streaming_service('stop')
            else:
                self.exec_streaming_service('stop')

        self.exec_streaming_service('start', multi)
        self.root.quit()

    def start_ap(self, multi=False):
        command = os.path.dirname(__file__) + '/scripts/start_ap.sh'
        command = command + (' multi' if multi else '')
        exec_command(command)
        self.root.quit()

    def exec_streaming_service(self, arg='stop', multi=False):
        command = os.path.dirname(__file__) + \
            '/scripts/exec_streaming_service.sh ' + arg
        if arg == 'start' and multi:
            command = command + ' multi'
        wait_flag = arg is 'stop'
        exec_command(command, wait=wait_flag)

    def get_ap_pass(self):
        command = 'grep wpa_passphrase /etc/hostapd/edu-cam | cut -d= -f2'
        outs, errs = exec_command(command, True)
        return outs.decode()[:-1]

    def change_ap_pass(self, password):
        command = os.path.dirname(__file__) + \
            '/scripts/change_ap_pass.sh ' + password
        exec_command(command, True)
        self.root.quit()


if __name__ == "__main__":
    frame = AppFrame(root)
    root.mainloop()
